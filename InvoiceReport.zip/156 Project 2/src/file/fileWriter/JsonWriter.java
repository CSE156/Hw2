package file.fileWriter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import file.data.Person;
import file.data.Product;
import file.data.Customer;

public class JsonWriter {
	// the converter for person
	public void jsonConverter(List<Person> personList){
	/*	Gson gson = new GsonBuilder().setPrettyPrinting().create();
		File jsonOutput = new File("data/Persons.json");
		
		PrintWriter jsonPrintWriter = null;
		
		try{
			jsonPrintWriter = new PrintWriter(jsonOutput);
		} catch (FileNotFoundException e){
			e.printStackTrace();
		}
		for (Person aPerson : personList){
			//convert object into a string
			String pOutput = gson.toJson(aPerson);
			jsonPrintWriter.write(pOutput +  "\n");
		}
		jsonPrintWriter.close();
	}
	public void cjsonConverter(List<Customer> customerList){
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		File jsonOutput = new File("data/Customers.json");
		
		PrintWriter jsonPrintWriter = null;
		
		try{
			jsonPrintWriter = new PrintWriter(jsonOutput);
		} catch (FileNotFoundException e){
			e.printStackTrace();
		}
		
		System.out.println(customerList.size());
		for (Customer aCustomer : customerList){
			//convert object into a string
			String cOutput = gson.toJson(aCustomer);
			jsonPrintWriter.write(cOutput +  "\n");
		}
		jsonPrintWriter.close();
	}
	
	public void pjsonConverter(List<Product> prodList){
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		File jsonOutput = new File("data/Products.json");
		
		PrintWriter jsonPrintWriter = null;
		
		try{
			jsonPrintWriter = new PrintWriter(jsonOutput);
		} catch (FileNotFoundException e){
			e.printStackTrace();
		}
		for (Product aProduct : prodList){
			//convert object into a string
			String prOutput = gson.toJson(aProduct);
			jsonPrintWriter.write(prOutput +  "\n");
		}
		jsonPrintWriter.close();*/
	}
}
