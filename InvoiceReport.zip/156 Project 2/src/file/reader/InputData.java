package file.reader;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import file.data.Address;
import file.data.Business;
import file.data.Person;
import file.data.Product;
import file.data.Residential;
import file.data.Consultation;
import file.data.Equipment;
import file.data.Invoice;
import file.data.Service;
import file.data.Customer;

public class InputData {
	public static ArrayList<Person> readPeople(){
		Scanner sc = null;
		
		try{
			File f = new File("data/Persons.dat");
			sc = new Scanner(f);
			sc.nextLine();
			ArrayList<Person> personList = new ArrayList<Person>();
			
			while(sc.hasNext()){
				String line = sc.nextLine();
				String data[]= line.split(";");
				String personCode = data[0];
				String names[] = data[1].split(",");
				String lastName = names[0];
				String firstName = names[1];
				String addresses[] = data[2].split(",");
				String street = addresses[0];
				String city = addresses[1];
				String state = addresses[2];
				String zipCode = addresses[3];
				String country = addresses[4];
				String emails[] = null;
				if(data.length == 4){
					emails = data[3].split(",");
				}
				
				
			Address address = new Address(street,city,state,zipCode,country);	
			Person person = new Person(personCode, lastName, firstName, address, emails);
				
				personList.add(person);
			
				for(int i = 0; i < personList.size(); i++){
				
				}
			}
			sc.close();
			return personList;
		
			
		} catch(FileNotFoundException e){
			e.printStackTrace();
			return null;
		}
		
	}
	//end of person start customer
	public static ArrayList<Customer> readCustomer(){
		ArrayList<Person> person = readPeople();
		Scanner sc = null;
		
		try{
			sc = new Scanner(new File("data/Customers.dat"));
			sc.nextLine();
			ArrayList<Customer> customerList = new ArrayList<Customer>();
			
			while(sc.hasNext()){
				String line = sc.nextLine();
				String token[] = line.split(";");
				String customerCode = token[0];
				String personCode = token[2];
				String name = token[3];
				String addresses[] = token[4].split(",");
				String street = addresses[0];
				String city = addresses[1];
				String state = addresses[2];
				String zipCode = addresses[3];
				String country = addresses[4];
				Address address = new Address(street,city,state,zipCode,country);
				double tax = 0;
				double complianceFee = 125;
				Person person2 = null;
				for(int i=0; i<person.size();i++){
					if(person.get(i).getPersonCode().equals(personCode)){
						person2 = person.get(i);
					}
				}
				if(token[1].equalsIgnoreCase("R")){
					String buisnesstype = token[1];
					Customer customer = new Residential(customerCode, buisnesstype, person2, name, address, tax, complianceFee);
					customerList.add(customer);
				}
				else if(token[1].equalsIgnoreCase("B")){
					String buisnesstype = token[1];
					Customer customer = new Business(customerCode, buisnesstype, person2, name, address, tax);
					customerList.add(customer);
				}
				
			}
			sc.close();
			System.out.println(customerList.size());
			
			return customerList;
	}
			catch(FileNotFoundException e){
				e.printStackTrace();
				return null;
			}
	}
	public static ArrayList<Product> readProd(){
		ArrayList<Person> person = readPeople();
		Scanner pd = null;
		
		try{
			pd = new Scanner(new File("data/Products.dat"));
			pd.nextLine();
			ArrayList<Product> prodList = new ArrayList<Product>();
			
			while(pd.hasNext()){
				String prodline = pd.nextLine();
				String proddata[]= prodline.split(";");
				String productCode = proddata[0];
				if(proddata[1].equals("E")){
					String productName = proddata[2];
					double price = Double.parseDouble(proddata[3]);
					Equipment equipment = new Equipment(productCode, productName, price);
					prodList.add(equipment);
				}
				else if(proddata[1].equals("C")){
					String productName = proddata[2];
					String personCode = proddata[3];
					Double hourlyFee = Double.parseDouble(proddata[4]);
					Person person3 = null;
					for(int i=0; i<person.size();i++){
						if(person.get(i).getPersonCode().equals(personCode)){
							person3 = person.get(i);
						}
					}
					Consultation consultation = new Consultation(productCode, productName, person3, hourlyFee);
					prodList.add(consultation);
				}
				else if(proddata[1].equals("S")){
					String productName = proddata[2];
					Double activationFee = Double.parseDouble(proddata[3]);
					Double annualFee = Double.parseDouble(proddata[4]);	
					Service service = new Service(productCode, productName, activationFee, annualFee);
					prodList.add(service);
				}
			}
			pd.close();
			return prodList;
		} catch(FileNotFoundException e){
			e.printStackTrace();
			return null;
		}
	}

	public static ArrayList<Invoice> readInvoice() throws FileNotFoundException, ParseException{
		ArrayList<Person> person = readPeople();
		ArrayList<Customer> customer = readCustomer();
		ArrayList<Product> prodList = readProd();
		Scanner iv = null;
		
	
			iv = new Scanner(new File("data/Invoices.dat"));
			iv.nextLine();
			ArrayList<Invoice> InvoiceList = new ArrayList<Invoice>();
			
			while(iv.hasNext()){
				String line = iv.nextLine();
				String data[]= line.split(";");
				String invoiceCode = data[0];
				String customerCode = data[1];
				Customer customer2 = null;
				for(int k=0; k < customer.size();k++){
					if(customer.get(k).getcustomerCode().equals(customerCode)){
						customer2 = customer.get(k);
					}
				}
				
				
				String date1[] = data[2].split("-");
				String invoiceDate =   date1[1] + "-" + date1[2] + "-" + date1[0];
//				SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy");
//				Date invoiceDate = format.parse(invoiceDate2);
				
				String personCode = data[3];
				Person salesPerson = null;
				for(int l=0; l<person.size();l++){
					if(person.get(l).getPersonCode().equals(personCode)){
						salesPerson = person.get(l);
					}
				}
				
				String line2[] = data[4].split(",");
				ArrayList<Product> product = new ArrayList<Product>();
				for( int i = 0; i < line2.length; i++){
					String[] line3 = line2[i].split(":");
					String productCode = line3[0];
						for (int j = 0; j < prodList.size(); j++){
							if(prodList.get(j).getProductCode().equals(productCode)){	
								if(prodList.get(j).getProdType().equals("S")){
									//Product product2 = new Service((Service)prodList.get(j));
									Service service = (Service)prodList.get(j);
									String line4[] = line3[1].split("-");
									String line5[] = line3[2].split("-");
									String dateStart = line4[1] + ("-") + line4[2] + ("-") + line4[0];
									String dateEnd = line5[1] + ("-") + line5[2] + ("-") + line5[0];
									
									SimpleDateFormat format2 = new SimpleDateFormat("MM-dd-yyyy");
									Date startDate = format2.parse(dateStart);
									
									
									SimpleDateFormat format3 = new SimpleDateFormat("MM-dd-yyyy");
									Date endDate = format3.parse(dateEnd);
									
									
									service.setStartDate(startDate);
									service.setEndDate(endDate);
//									System.out.println(dateStart);
//									System.out.println(dateEnd);
									for(int m=0; m < customer.size();m++){
										if(customer.get(m).getcustomerType().equals("B")){
											Business.setTax(.0425);
										}
									}
									product.add(service);
								}
								else if(prodList.get(j).getProdType().equals("E")){
									Equipment equipment = (Equipment)prodList.get(j);
									double units = Double.parseDouble(line3[1]);
									equipment.setUnits(units);
									
									for(int m=0; m < customer.size();m++){
										if(customer.get(m).getcustomerType().equals("B")){
											Business.setTax(.07);
										}
									}
									product.add(equipment);
								}
								else if(prodList.get(j).getProdType().equals("C")){
									Consultation consultation = (Consultation)prodList.get(j);
									double hours = Double.parseDouble(line3[1]);
									consultation.setHours(hours);
									product.add(consultation);
									for(int m=0; m < customer.size();m++){
										if(customer.get(m).getcustomerType().equals("B")){
											Business.setTax(.0425);
										}
									}
									
								}
							
					}
				}
				
				
			}
			Invoice invoice = new Invoice(invoiceCode, invoiceDate, customer2, salesPerson, product);
			InvoiceList.add(invoice);
			
			
		}	
			iv.close();
				return InvoiceList;

}
	
	public static void main(String args[]) throws FileNotFoundException, ParseException{
		
		List<Person> person = readPeople();
		
		StringBuilder personReport = new StringBuilder();
		
		personReport.append(String.format("%-30s %-30s %-30s %-30s %30s\n", 
				"Person Code", "First", "Last", "Address", "Email")); 
		
		for(Person personList : person) {
			
			personReport.append(String.format("%-30s %-30s %-30s %-30s %-10s %-10s %-10s %-10s %-30s\n", 
					personList.getPersonCode(), personList.getFirstname(), personList.getLastName(), personList.getAddress().getStreet(),
					personList.getAddress().getCity(), personList.getAddress().getZipCode(), personList.getAddress().getState(), personList.getAddress().getCountry(), 
					personList.getEmail())); 
		}
		
		List<Invoice> invoice = readInvoice();
		//ArrayList<Customer> customer = readCustomer();
		//ArrayList<Product>product = readProd();
		
		
		
		
		
		StringBuilder invoiceReport = new StringBuilder();
		
		invoiceReport.append(String.format("Invoice Summary Report\n"));
		invoiceReport.append(String.format("=================================================================================================================================\n"));

		
		invoiceReport.append(String.format("%-10s %-35s %-20s %-15s %-15s %-15s %-15s\n", 
				"Invoice", "Customer", "SalesPerson", "SubTotal", "Fees", "Taxes", "Total" ));
		invoiceReport.append(String.format("=================================================================================================================================\n"));

		double InvoiceSubtotal = 0;
		double InvoiceFee = 0;
		double InvoiceTax = 0;
		double InvoiceTotal = 0;
		double TotalSubtotal = 0;
		double TotalTax = 0;
		double TotalFees = 0;
		double TotalTotal = 0;
		for(Invoice invoiceList : invoice) {
			
			InvoiceSubtotal = 0;
			InvoiceFee = 0;
			InvoiceTax = 0;
			InvoiceTotal = 0;
			Product product = null;
			Customer customer = null;
			//System.out.println("\n\n\n" +invoiceList.getProduct().size());
			for(int i = 0; i < invoiceList.getProduct().size(); i++){
				
				product = invoiceList.getProduct().get(i);
				customer = invoiceList.getCustomer();
				//System.out.println(product);
				
				if( product.getProdType().equals("E")){
					double IndividualSubtotal = product.getSubTotal();
					InvoiceSubtotal += IndividualSubtotal;
					TotalSubtotal += InvoiceSubtotal;
					double IndividualFee = product.getFees();
					InvoiceFee += IndividualFee;
					TotalFees += InvoiceFee;
					
					if(customer.getcustomerType().equals("B")){
						double IndividualTax = .07;
						InvoiceTax = IndividualTax * InvoiceSubtotal;
						InvoiceTotal = InvoiceTax + InvoiceFee + InvoiceSubtotal;
						TotalTax +=InvoiceTax;
						TotalTotal = TotalSubtotal + TotalFees + TotalTax;
					}
					
					else if(customer.getcustomerType().equals("R")){
						InvoiceFee += 125;
						InvoiceTotal = InvoiceTax + InvoiceFee + InvoiceSubtotal;
						TotalFees += InvoiceFee;
						TotalTotal = TotalSubtotal + TotalFees + TotalTax;
					}
						
				}
				else if( product.getProdType().equals("S")){
					double IndividualSubtotal = product.getSubTotal();
					InvoiceSubtotal += IndividualSubtotal;
					TotalSubtotal += InvoiceSubtotal;
					double IndividualFee = product.getFees();
					InvoiceFee += IndividualFee;
					TotalFees += InvoiceFee;
					if(customer.getcustomerType().equals("B")){
						double IndividualTax = .0425;
						InvoiceTax = IndividualTax * InvoiceSubtotal;
						InvoiceTotal = InvoiceTax + InvoiceFee + InvoiceSubtotal;
						TotalTax +=InvoiceTax;
						TotalTotal = TotalSubtotal + TotalFees + TotalTax;
					}
					
					else if(customer.getcustomerType().equals("R")){
						InvoiceTotal = InvoiceTax + InvoiceFee + InvoiceSubtotal;
						TotalTotal = TotalSubtotal + TotalFees + TotalTax;
					}

				}
				else if( product.getProdType().equals("C")){
					double IndividualSubtotal = product.getSubTotal();
					InvoiceSubtotal += IndividualSubtotal;
					TotalSubtotal += InvoiceSubtotal;
					double IndividualFee = product.getFees();
					InvoiceFee += IndividualFee;
					TotalFees += InvoiceFee;
					if(customer.getcustomerType().equals("B")){
						double IndividualTax = .0425;
						InvoiceTax = IndividualTax * InvoiceSubtotal;
						InvoiceTotal = InvoiceTax + InvoiceFee + InvoiceSubtotal;
						TotalTax +=InvoiceTax;
						TotalTotal = TotalSubtotal + TotalFees + TotalTax;
					}
					else if(customer.getcustomerType().equals("R")){
						InvoiceTotal = InvoiceTax + InvoiceFee + InvoiceSubtotal;
						TotalTotal = TotalSubtotal + TotalFees + TotalTax;
					}

				}
			}	
			invoiceReport.append(String.format("%-10s %-35s %-20s %-15f %-15f %-15f %-15f \n", 
					invoiceList.getInvoiceCode(), invoiceList.getCustomer().getname(), invoiceList.getSalesperson().getFullName(), InvoiceSubtotal, InvoiceFee, InvoiceTax, InvoiceTotal ));		
		
		}
		
		invoiceReport.append(String.format("=================================================================================================================================\n"));
		invoiceReport.append(String.format("%-67s %-15f %-15f %-15f %-15f \n",
				"Totals", TotalSubtotal, TotalFees, TotalTax, TotalTotal));
		invoiceReport.append(String.format("\n\n=====================================\n"));
		invoiceReport.append(String.format("INVOICE DETAIL REPORT\n"));
		invoiceReport.append(String.format("=====================================\n"));
		invoiceReport.append(String.format("\n-------------------------------------\n"));
		
		for(Invoice invoiceList : invoice){
			
		invoiceReport.append(String.format("Invoice: " + invoiceList.getInvoiceCode() + "\n"));
		invoiceReport.append(String.format("Date: " + invoiceList.getInvoiceDate() + "\n"));
		invoiceReport.append(String.format("\n-------------------------------------\n"));
		invoiceReport.append(String.format("Sales Person: " + invoiceList.getSalesperson().getFullName() + "\n"));
		invoiceReport.append(String.format("Customer: \n"));
		invoiceReport.append(String.format("	" + invoiceList.getCustomer().getname() + "\n"));
		if(invoiceList.getCustomer().getcustomerType().equals("B")){
		invoiceReport.append(String.format("	" + "(Business)" + "\n"));
		}
		else if(invoiceList.getCustomer().getcustomerType().equals("R")){
			invoiceReport.append(String.format("	" + "(Residential)" + "\n"));
		}
		invoiceReport.append(String.format("	" + "[" + invoiceList.getCustomer().getsalesPerson().getFullName() + "]" + "\n"));
		invoiceReport.append(String.format("	" + invoiceList.getCustomer().getaddress().getStreet() + "\n"));
		invoiceReport.append(String.format("       " + invoiceList.getCustomer().getaddress().getCity() + "," + invoiceList.getCustomer().getaddress().getState() + 
				invoiceList.getCustomer().getaddress().getZipCode() + " " + invoiceList.getCustomer().getaddress().getCountry() + "\n"));
		invoiceReport.append(String.format("\n-------------------------------------\n"));
		invoiceReport.append(String.format("%-10s %-55s %-20s %-15s %-15s %-15s\n", 
				"Code", "Item", "Subtotal", "Taxes", "Fees", "Total" ));
		Product product = null;
		Customer customer = null;
		double TotalInvoiceSubtotal = 0;
		double TotalInvoiceTax = 0;
		double TotalInvoiceFee = 0;
		
		for(int i = 0; i < invoiceList.getProduct().size(); i++){
			product = invoiceList.getProduct().get(i);
			
			customer = invoiceList.getCustomer();
			double Tax = 0;
			if( product.getProdType().equals("E")){
				
				if(customer.getcustomerType().equals("B")){
					double IndividualTax = .07;
					Tax = IndividualTax*product.getSubTotal();
				}
				
				if(customer.getcustomerType().equals("R")){
					InvoiceFee += 125;
					InvoiceTotal = InvoiceTax + InvoiceFee + InvoiceSubtotal;
				}
					
			}
			else if( product.getProdType().equals("S")){
				
				if(customer.getcustomerType().equals("B")){
					double IndividualTax = .0425;
					Tax = IndividualTax*product.getSubTotal();
				}
				
				if(customer.getcustomerType().equals("R")){
					InvoiceTotal = InvoiceTax + InvoiceFee + InvoiceSubtotal;
				}

			}
			else if( product.getProdType().equals("C")){
				
				if(customer.getcustomerType().equals("B")){
					double IndividualTax = .0425;
					Tax = IndividualTax*product.getSubTotal();
				}
				if(customer.getcustomerType().equals("R")){
					InvoiceTotal = InvoiceTax + InvoiceFee + InvoiceSubtotal;
				}

			}
			
			
		invoiceReport.append(String.format("%-10s %-55s %-20f %-15s %-15f %-15f \n", 
				product.getProductCode(), product.getProductName() + "  " + "(" + product.getNumber() + " " + product.pluralDescriptor() + " at " + product.getNumber2() + "/" + 
		product.descriptor() + ")", product.getSubTotal(), Tax,  product.getFees(), InvoiceTotal ));
		}
		}

	
		System.out.println(invoiceReport);
	}
}
			
			
			
			
			
			
			