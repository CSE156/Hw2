package file.converter;

//import javax.sql.rowset.spi.XmlWriter;
import file.reader.InputData;
import file.data.Person;
import file.data.Product;
import file.fileWriter.JsonWriter;
import file.data.Customer;

import java.util.ArrayList;
//import java.util.List;


public class DataConverter {
	/*public static void main(String[] args){
		InputData id = new InputData();
		ArrayList<Person> personList = id.readPeople();
		
		JsonWriter jWriter = new JsonWriter();
		jWriter.jsonConverter(personList);
		
		InputData pd = new InputData();
		ArrayList<Product> prodList = pd.readProd();
		
		JsonWriter pWriter = new JsonWriter();
		pWriter.pjsonConverter(prodList);
		
		InputData cd = new InputData();
		ArrayList<Customer> customerList = cd.readCustomer(personList);
		
		JsonWriter cWriter = new JsonWriter();
		cWriter.cjsonConverter(customerList);
	}	
		XmlWriter xmlWriter = new XMLWriter();
		xmlWriter .xmlConverter(personList);
		*/
	
}
