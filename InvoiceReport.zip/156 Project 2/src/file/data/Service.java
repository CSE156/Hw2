package file.data;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Service extends Product {
	
	private double activationFee;
	private double annualFee;
	private Date startDate;
	private Date endDate;
	private double numOfDays;
	private double number;
	private double number2;
	//private double subTotal;
	
	
	public Service(String productCode, String productName, double activationFee, double annualFee){
		super(productCode, productName);

		this.activationFee = activationFee;
		this.annualFee = annualFee;
		
	}
	public Service(Service c)
	{
		super(c.getProductCode(),c.getProductName());
		this.activationFee = c.getactivationFee();
		this.annualFee = c.getannualFee();
		this.startDate = c.getStartDate();
		this.endDate = c.getEndDate();
		this.numOfDays = c.getNumOfDays();
	}
	
	public String toString()
	{
		return productName + "\nActivation Fee: " + activationFee + "\nAnnual Fee: " + annualFee + "\nStart Date: " + startDate.toString() + "\nEnd Date: " + endDate.toString() + "\nSubtotal: " + getSubTotal();
	}
	
	public double getactivationFee(){
		return this.activationFee;
	}
	public double getannualFee(){
		return this.annualFee;
	}
	
	public String getProdType(){
		return "S";
	}
	public void setannualFee(double annualFee){
		this.annualFee = annualFee;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;

		
			long diff = this.endDate.getTime() - startDate.getTime();

//			 setNumOfDays(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) +1);

			 this.numOfDays = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) +1;
//			 System.out.println(productName);
//			System.out.println(numOfDays);
//			System.out.println("annual fee " + annualFee);
//			System.out.println((numOfDays/365) * annualFee);
	}
	
	public double getNumOfDays() {
		return numOfDays;
	}

	public void setNumOfDays(double numOfDays) {
		this.numOfDays = numOfDays;
	}
	@Override
	public double getSubTotal() {
		return ((numOfDays/365) * annualFee);
	}
	@Override
	public double getFees() {
		
		return activationFee;
	}
	
	public String descriptor(){
		return "year";
	}
	
	public String pluralDescriptor(){
		return "days";
	}

	@Override
	public double getNumber() {
		number = numOfDays;
		return number;
	}
	@Override
	public double getNumber2() {
		number2 = annualFee;
		return number2;
	}
	
}









