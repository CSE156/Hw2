package file.data;

public class Consultation extends Product {

	private double hourlyFee;
	private double serviceFee = 150;
	private Person salesPerson;
	private double hours;
	private double number;
	private double number2;
	
	
	public Consultation(String productCode, String productName, Person salesPerson, double hourlyFee){
	super(productCode, productName);
	this.hourlyFee = hourlyFee;
	this.setSalesPerson(salesPerson);
	}
	
	public Consultation(Consultation c)
	{
		super(c.getProductCode(),c.getProductName());
		this.hourlyFee = c.gethourlyFee();
		this.salesPerson = c.getSalesPerson();
		this.hours = c.getHours();
	}
	
	public double gethourlyFee(){
		return this.hourlyFee;
	}
	public void sethourlyFee(double hourlyFee){
		this.hourlyFee = hourlyFee;
	}
	public String getproductCode() {
		return productCode;
	}
	public String getProdType(){
		return "C";
	}

	public Person getSalesPerson() {
		return salesPerson;
	}

	public void setSalesPerson(Person salesPerson) {
		this.salesPerson = salesPerson;
	}

	public double getHours() {
		return hours;
	}

	public void setHours(double hours) {
		this.hours = hours;
	}

	public double getServiceFee() {
		return serviceFee;
	}

	public void setServiceFee(double serviceFee) {
		this.serviceFee = serviceFee;
	}
	
	//private double subTotal;
	
	@Override
	public double getSubTotal() {
		return (hours*hourlyFee);
	}

	@Override
	public double getFees() {
		
		return serviceFee;
	}
	
	public String descriptor(){
		return "hour";
	}
	
	public String pluralDescriptor(){
		return "hrs";
	}

	@Override
	public double getNumber() {
		number = hours;
		return number;
	}
	
	@Override
	public double getNumber2() {
		number2 = hourlyFee;
		return number2;
	}
	
}