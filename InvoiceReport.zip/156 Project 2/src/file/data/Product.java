package file.data;

public abstract class Product {
	protected String productName;
	protected String productCode;
	//private double subTotal;
	
	public Product(String productCode, String productName){
		this.productName = productName;
		this.productCode = productCode;
		
	}
	
	
	
	public String toString()
	{
		return productName;
	}
	public String getProductName(){
		return productName;
	}
	public void setProductName(String productName){
		this.productName = productName;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public abstract String getProdType();
	
	public abstract double getSubTotal(); 
	
	public abstract double getFees();
	
	public abstract String descriptor();
	
	public abstract String pluralDescriptor();
	
	public abstract double getNumber();
	
	public abstract double getNumber2();
	
}
