package file.data;

public class Residential extends Customer {
		private double complianceFee;
		private double tax;
	
		public Residential(String customerCode, String buisnesstype, Person contact, String name, Address address,
				double tax, double complianceFee) {
			super(customerCode, buisnesstype, contact, name, address, tax, complianceFee);
			Residential.setComplianceFee(complianceFee);
			this.tax = tax;
		}

		public double getTax() {
			return tax;
		}
		
		public void setTax(double tax) {
			this.tax = tax;
		}

		public double getComplianceFee() {
			return complianceFee;
		}

		public static void setComplianceFee(double complianceFee) {
			
		}

}
