package file.data;

public class Person {
	private String personCode;
	private String firstName;
	private String lastName;
	private Address address;
	private String[] email;
	//private String fullName;
	
	public Person(String personCode, String lastName, 
	String firstName, Address address, String[] email){
		super();
		this.personCode = personCode;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.email = email;
	}
	
	public Address getAddress(){
		return this.address;
	}
	public String[] getEmail(){
		return this.email;
	}
	public void setEmail(String[] email){
		this.email = email;
	}
	public String getPersonCode(){
		return this.personCode;
	}
	public void setPersonCode(String personCode){
		this.personCode = personCode;
	}
	public String getFirstname(){
		return this.firstName;
	}
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	public String getLastName(){
		return this.lastName;
	}
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	
	public String getFullName() {
		return lastName + "," + firstName;
	}

	
	
}
