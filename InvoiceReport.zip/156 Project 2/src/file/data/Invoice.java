package file.data;

import java.util.ArrayList;
import java.util.Date;

public class Invoice {
	private String invoiceCode;
	private String invoiceDate;
	private Customer customer;
	private Person salesperson;
	private ArrayList<Product> product;
		public Invoice(String invoiceCode, String invoiceDate, Customer customer, Person salesperson, ArrayList<Product> product){
			this.setInvoiceCode(invoiceCode);
			this.setInvoiceDate(invoiceDate);
			this.setCustomer(customer);
			this.setSalesperson(salesperson);
			this.setProduct(product);
		}
		public String getInvoiceCode() {
			return invoiceCode;
		}
		public void setInvoiceCode(String invoiceCode) {
			this.invoiceCode = invoiceCode;
		}
		public String getInvoiceDate() {
			return invoiceDate;
		}
		public void setInvoiceDate(String invoiceDate) {
			this.invoiceDate = invoiceDate;
		}
		public Customer getCustomer() {
			return customer;
		}
		public void setCustomer(Customer customer) {
			this.customer = customer;
		}
		public Person getSalesperson() {
			return salesperson;
		}
		public void setSalesperson(Person salesperson) {
			this.salesperson = salesperson;
		}
		public ArrayList<Product> getProduct() {
			return product;
		}
		public void setProduct(ArrayList<Product> product) {
			this.product = product;
		}
		
		

}
