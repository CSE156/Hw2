package file.data;

public abstract class Customer {
	private String customerCode;
	private Person salesPerson;
	private String name;
	private Address address;
	private String customerType;

	public Customer (String customerCode, String customerType, Person salesPerson, String name, Address address, double tax,  double complianceFee){
		this.customerCode = customerCode;
		this.salesPerson = salesPerson;
		this.name = name;
		this.address = address;
		this.customerType = customerType;
	}
	
	public Customer (String customerCode, String customerType, Person salesPerson, String name, Address address, double tax){
		this.customerCode = customerCode;
		this.salesPerson = salesPerson;
		this.name = name;
		this.address = address;
		this.customerType = customerType;
		}
	
	
	public String getcustomerCode(){
		return this.customerCode;
	}
	public Person getsalesPerson(){
		return this.salesPerson;
	}
	public String getname(){
		return this.name;
	}
	public Address getaddress(){
		return this.address;
	}
	public String getcustomerType(){
		return this.customerType;
	}
		
}
