package file.data;

public class Consultant {
	
	private String personCode;
	private String firstName;
	private String lastName;
	private Address address;
	private Email email;
	
	public Consultant(String personCode, String firstName, String lastName, Address address, Email email){
	super();
	this.personCode = personCode;
	this.firstName = firstName;
	this.lastName = lastName;
	this.address = address;
	this.email = email;
	}
	
	public String getpersonCode(){
		return this.personCode;
	}
	
	public String getfirstName(){
		return this.firstName;
	}
	
	public String getlastName(){
		return this.lastName;
	}
	
	public Address getaddress(){
		return this.address;
	}
	
	public Email getemail(){
		return this.email;
	}
	

		

}