package file.data;

public class Business extends Customer {
	private double tax;
	
	public Business(String customerCode, String buisnesstype, Person contact, String name, Address address,
			double tax) {
		super(customerCode, buisnesstype, contact, name, address, tax);
		Business.setTax(tax);
	}

	public double getTax() {
		return tax;
	}

	public static void setTax(double tax) {
		
	}

}
