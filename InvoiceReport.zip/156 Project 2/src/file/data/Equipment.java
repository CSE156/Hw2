package file.data;


public class Equipment extends Product{
	
	private double price;
	private double units;
	private double number;
	private double number2;
	
	//private double subTotal;

	public Equipment(String productCode, String productName, double price){
		super(productCode, productName);
		this.price = price;
	}
	public Equipment(Equipment c)
	{
		super(c.getProductCode(),c.getProductName());
		this.price = c.getprice();
		this.units = c.getUnits();
		
	}
	public String descriptor(){
		return "unit";
	}
	
	public String pluralDescriptor(){
		return "units";
	}
	
	public double getprice(){
	return this.price;
	}

	public String getProdType(){
		return "E";
	}

	public Double getUnits() {
		return units;
	}

	public void setUnits(Double units) {
		this.units = units;
	}
	@Override
	public double getSubTotal() {
		return (price*units);
	}
	@Override
	public double getFees() {
		
		return 0;
	}
	@Override
	public double getNumber() {
		number = units;
		return number;
	}
	@Override
	public double getNumber2() {
		number2 = price;
		return number2;
	}

	
	
}